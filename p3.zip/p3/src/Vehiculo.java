import java.util.*;

public class Vehiculo {

    //Possible colors
    public enum Color {ROJO, VERDE, AZUL,DEFAULT}

    //Atributes

    private Color color;
    int numeroRuedas ;
    double velocidadRecta = 0;
    double velocidadCurva = 0;

    public Vehiculo(Color color){
        this.color = color;
        velocidadCurva = 30;
        velocidadRecta = 30;
    }

    public Vehiculo(Vehiculo vehiculo){
        this.color = vehiculo.color;
        this.velocidadRecta = velocidadRecta;
        this.velocidadCurva = velocidadCurva;
        this.numeroRuedas = vehiculo.numeroRuedas;
    }

    public Color color(){
        return color;
    }
    public void setColor(Color c){
        color = c;
    }
    public double getVelocidadCurva() {
        return velocidadCurva;
    }

    public void setVelocidadCurva(double velocidadCurva) {
        this.velocidadCurva = velocidadCurva;
    }

    public double getVelocidadRecta() {
        return velocidadRecta;
    }

    public void setVelocidadRecta(double velocidadRecta) {
        this.velocidadRecta = velocidadRecta;
    }
    public void acelerarRecta(){
        setVelocidadRecta(getVelocidadRecta()+15);
    }
    public void acelerarCurva(){
        setVelocidadCurva(getVelocidadCurva()+5);
    }
    public void frenarRecta(){
        setVelocidadRecta(getVelocidadRecta()-15);
        if(getVelocidadRecta()<= 0){
            setVelocidadRecta(0);
        }
    }
    public void frenarCurva(){
        setVelocidadCurva(getVelocidadCurva()-5);
        if(getVelocidadCurva()<=0){
            setVelocidadCurva(0);
        }
    }
    public void mejorar(){
        setVelocidadRecta(getVelocidadRecta()+15);
        setVelocidadCurva(getVelocidadCurva()+15);
    }

    public double tiempoRecta(double distancia){
        if (getVelocidadRecta() <= 0){
            return -1;
        }else{
            return distancia/getVelocidadRecta();
        }


    }
    public double tiempoCurva(double distancia){
        if (getVelocidadCurva() <= 0 ){
            return -1;
        }else{
            return distancia/getVelocidadCurva();
        }

    }



}

class Coche extends Vehiculo{
    private final int numRuedas = 4;

     Coche(Color color) {
        super(color);
    }
}

class Bicicleta extends Vehiculo{
    private final int numberWheels = 2;

     Bicicleta(Color color) {
        super(color);
    }
}

class Camion extends Vehiculo{
    private final int numRuedas = 10;

    Camion(Color color) {
        super(color);
    }
}

class Tren extends Vehiculo{
    List<Vagon> listVagones = new ArrayList<>();

    public Tren(Color color) {
        super(color);
        Locomotora locomotora;
    }

    public boolean addVagon(Vagon vagon){
        return listVagones.add(vagon);
    }
    public int tamlista(){
        return listVagones.size();
    }
    public boolean removeRandom(){
        return listVagones.remove(Math.random()*listVagones.size() +1);
    }
    public void removeAll(){
        listVagones.clear();
    }
    public double getNumRuedas(){
        double ruedasTot=4;
        for (int i= 0; i< listVagones.size();i++){
            ruedasTot += listVagones.get(i).numeroRuedas;
        }
        return ruedasTot;
    }
    public double getNumAsientos(){
        double asientosTot=0;
        for (int i= 0; i< listVagones.size();i++){
            asientosTot += listVagones.get(i).numAsientos;
        }
        return asientosTot;
    }
}

class Vagon extends Tren{
    Random rd;
    public int numAsientos = (int) (Math.random() * 100) + 1;
    public int numRuedas;
    public Vagon(Color color, int numRuedas) {
        super(color);

        if(numRuedas != 4 && numRuedas != 6){
            throw new RuntimeException("El numero de ruedas del Vagon ha de ser 6 u 8");
        }else{
            this.numeroRuedas =numRuedas;
        }
    }
}
class Locomotora extends Tren{
    private int numRuedas = 8;

    public Locomotora(Color color) {
        super(color);
        numRuedas= 8;
    }
}

class DemoVehiculo{

    public static void printMenu2(){
        System.out.println("");
        System.out.println("1. Acelerar vehiculo en recta");
        System.out.println("2. Acelerar vehiculo en curva");
        System.out.println("3. Frenar vehiculo en recta");
        System.out.println("4. Frenar vehiculo en curva");
        System.out.println("5. Mejorar vehiculo");
        System.out.println("6. Calcular tiempo en recta");
        System.out.println("7. Calcular tiempo en curva");
        System.out.println("8. Volver Inicio");
        System.out.println("Seleccione la opción que desee:");
    }
    public static void printMenu1(){
        System.out.println("");
        System.out.println("Opciones disponibles:");
        System.out.println("1. Crear nuevo vehiculo");
        System.out.println("2. Ver vehiculos creados");
        System.out.println("3. Salir");
    }
    public static void printMenuTrain(){
        System.out.println("");
        System.out.println("0. Añadir Vagon");
        System.out.println("1. Acelerar vehiculo en recta");
        System.out.println("2. Acelerar vehiculo en curva");
        System.out.println("3. Frenar vehiculo en recta");
        System.out.println("4. Frenar vehiculo en curva");
        System.out.println("5. Mejorar vehiculo");
        System.out.println("6. Calcular tiempo en recta");
        System.out.println("7. Calcular tiempo en curva");
        System.out.println("8. Volver Inicio");
        System.out.println("Seleccione la opción que desee:");
    }
    public static void main(String[] args) {

        List<Vehiculo> listaVehiculos = new ArrayList<>();
        System.out.println("Bienvenido");
        while(true){
            int opcion3 = 0;
            Vehiculo v = new Vehiculo(Vehiculo.Color.ROJO); //To initialize
            printMenu1();
            Scanner reader = new Scanner(System.in);
            int opcion1 = 0;
            opcion1 = reader.nextInt();
            if (opcion1 == 1){
                v = crearVehiculo();
                listaVehiculos.add(v);
            }else if(opcion1 == 2){
                leerLista(listaVehiculos);
            }else if(opcion1 == 3){
                break;
            }else{
                throw new RuntimeException("Opcion incorrecta");
            }
            while(opcion3 != 8 && opcion1 !=2 ){

                printMenu2();
                reader = new Scanner(System.in);
                opcion3 = reader.nextInt();
                interacciones(v,opcion3);
            }
        }
    }
    public static Tren addVagones(Tren tren){

        System.out.println("Indique cuantas ruedas tiene el Vagon (4 o 6):");
        Scanner reader = new Scanner(System.in);
        int opcion1 = 0;
        opcion1 = reader.nextInt();

        System.out.println("Indique el color del vagon (1. Rojo 2. Azul 3.Verde)");
        reader = new Scanner(System.in);
        int opcion2 = 0;
        opcion2 = reader.nextInt();
        Vagon v = new Vagon(Vehiculo.Color.DEFAULT, opcion1);
        v = (Vagon) crearVehiculoColor(v,opcion2);
        tren.addVagon(v);
        
        return tren;
    }
    public static Vehiculo crearVehiculo(){
        System.out.println("Indique tipo vehiculo (1.Coche 2.Camion 3.Bicicleta 4.Tren)");
        Scanner reader = new Scanner(System.in);
        int opcion1 = 0;
        opcion1 = reader.nextInt();
        
        if (opcion1 == 4){//In case it is a train
            Vehiculo v = crearTipoVehiculo(opcion1);
            v = crearVehiculoColor(v, 4);
            int opcion2 = 1;
            System.out.println("Opciones: 1 Añadir Vagones, 2 Tren terminado");
            reader = new Scanner(System.in);
            opcion2 = reader.nextInt();
            while(opcion2 == 1){
                v = addVagones((Tren) v);
                System.out.println("Opciones: 1 Añadir Vagones, 2 Tren terminado");
                reader = new Scanner(System.in);
                opcion2 = reader.nextInt();

            }
            return v;
        }else{
            System.out.println("Indique color del vehiculo (1. Rojo 2.Azul 3.Verde)");
            reader = new Scanner(System.in);
            int opcion2 = 0;
            opcion2 = reader.nextInt();
            Vehiculo v = crearTipoVehiculo(opcion1);
            return crearVehiculoColor(v, opcion2);

        }
    }
    public static Vehiculo crearVehiculoColor(Vehiculo v,int opcion1){

        switch (opcion1){
            case 1:
                v.setColor(Vehiculo.Color.ROJO);
                break;
            case 2:
                v.setColor(Vehiculo.Color.AZUL);
                break;
            case 3:
                v.setColor(Vehiculo.Color.VERDE);
                break;
            case 0:
                v.setColor(Vehiculo.Color.DEFAULT);
                break;
        }
        return v;
    }
    public static Vehiculo crearTipoVehiculo(int opcion){
        switch (opcion){
            case 1:
                return new Coche(Vehiculo.Color.DEFAULT);
            case 2:
                return new Camion(Vehiculo.Color.DEFAULT);
            case 3:
                return new Bicicleta(Vehiculo.Color.DEFAULT);
            case 4:
                return new Tren(Vehiculo.Color.DEFAULT);
            case 5:
                System.out.println("Indique color del Vagon (1. Rojo 2.Azul 3.Verde)");
                Scanner reader = new Scanner(System.in);
                int opcion1 = 0;
                opcion1 = reader.nextInt();

                System.out.println("Indique el numero de ruedas 4 0 6");
                reader = new Scanner(System.in);
                int opcion2 = 0;
                opcion2 = reader.nextInt();
                Vagon v = new Vagon(Vehiculo.Color.DEFAULT,opcion2);
                if (opcion1 == 1){
                    return new Vagon(Vehiculo.Color.ROJO,opcion2);
                }else if(opcion1 == 2){
                    return new Vagon(Vehiculo.Color.AZUL,opcion2);
                }else if( opcion1 == 3){
                    return new Vagon(Vehiculo.Color.VERDE, opcion2);
                }else {

                }
            default:
                throw new RuntimeException("Opciones incorrectas");
        }
    }
    public static void interacciones(Vehiculo v, int opcion){

        Scanner reader;
        switch (opcion){
            case 1:
                v.acelerarRecta();
                System.out.println("Coche acelerado en recta");
                break;
            case 2:
                v.acelerarCurva();
                System.out.println("Coche acelerado en curva");
                break;
            case 3:
                v.frenarRecta();
                System.out.println("Coche frenado en recta");
                break;
            case 4:
                v.frenarCurva();
                System.out.println("Coche frenado en curva");
                break;
            case 5:
                v.mejorar();
                System.out.println("Coche mejorado");
                break;
            case 6:
                System.out.println("Introduzca distancia recta:");
                reader = new Scanner(System.in);
                double distanciaR = reader.nextDouble();
                double tiempoR = v.tiempoRecta(distanciaR);
                System.out.println("Tiempo en recorrer "+tiempoR);
                break;
            case 7:
                System.out.println("Introduzca distancia curva:");
                reader = new Scanner(System.in);
                double distanciaC = reader.nextDouble();
                double tiempoC = v.tiempoCurva(distanciaC);
                System.out.println("Tiempo en recorrer "+tiempoC);
                break;
            case 8:
                double velocidadR, velocidadC;
                velocidadR = v.getVelocidadRecta();
                velocidadC = v.getVelocidadCurva();
                System.out.println("VelocidadRecta "+velocidadR);
                System.out.println("VelocidadCurva "+velocidadC);
                break;

        }
    }
    public static void leerLista(List<Vehiculo> listaVehiculos){
        if (listaVehiculos.isEmpty()){
            System.out.println("No hay ningun vehiculo");
        }else{
            for (int i= 0; i< listaVehiculos.size();i++){
                System.out.println(listaVehiculos.get(i).getClass().getName()+" "+ listaVehiculos.get(i).color()+" "+ "id "+i);
                if (listaVehiculos.get(i).getClass().getName() == "Tren"){
                    Tren t = (Tren) listaVehiculos.get(i);
                    
                    for (int j = 0;j<t.listVagones.size();j++){
                        System.out.println("     Vagon numero "+j+" de color "+t.listVagones.get(j).color()+" con "+ t.listVagones.get(j).numAsientos+" asientos "+" y "+ t.listVagones.get(j).numeroRuedas+" ruedas ");
                    }
                }

                
            }
        }

    }
}