import java.util.Scanner;

/*This program offers a menu with three different options, first it shows a Menu
displaying the possibilities there are. To choose one, a number between 1 and 3 has
to be introduced.
*/
public class p1 {
    //Constants needed for the execution

    private static final int MAX = 100 ;
    public final static double PRECIO_TRAMO1 = 0.15;
    public final static double PRECIO_TRAMO2 = 0.20;
    public final static double PRECIO_TRAMO3 = 0.35;
    public final static double PRECIO_TRAMO4 = 0.80;

    /*
    * In calculoConsumo() we receive the quantity of water that is consumed,
    *  we receive it as double as it can have decimals.
    *
    * as there are different sections, we check in which section the received number is,
    * First we check if there is water above the first section, if there is, we check if there is above the second,
    * and the same for the third section.
    *
    * The returned double value is the money we have to pay for the water consumed
    *  */

    public static double calculoConsumo(double numero){

        double cuenta = 0;
        if (numero <= 0){
            System.out.print("El numero introducido no es correcto");
        }else{

            if (numero < 100){ //Checking if it is first or second section

                cuenta = numero * PRECIO_TRAMO1;//First section

            }else if(numero < 600 && numero >= 100){//Checking if it is second or third section

                //Second section
                numero = numero - 100;
                cuenta = 100 * PRECIO_TRAMO1 + numero * PRECIO_TRAMO2;

            }else if (numero < 1100 && numero >= 600){//Checking if its third or fourth section

                //Third section
                numero= numero - 100;
                cuenta = 100 * PRECIO_TRAMO1;
                numero = numero -500;
                cuenta += 500 * PRECIO_TRAMO2;

                cuenta += numero* PRECIO_TRAMO3;


            }else if (numero > 1100){

                //fourth section
                numero= numero - 100;
                cuenta = 100 * PRECIO_TRAMO1;
                numero = numero -500;
                cuenta += 500 * PRECIO_TRAMO2;
                numero = numero - 500;
                cuenta +=  500 * PRECIO_TRAMO3;
                cuenta += numero * PRECIO_TRAMO4;
            }
        }

        System.out.println("Debe pagar "+cuenta+ " euros");
        return 1;
    }

    /*
    *
    * */
    public static String calculoTemp(int numero){

        double count = 0;
        int countNegativas = 0;
        double temperaturas[] = new double[numero];

        for (int i =0 ; i <numero;i++){
            Scanner temperatura = new Scanner(System.in);
            temperaturas[i] = temperatura.nextDouble();

        }

        for (int i = 0; i< temperaturas.length;i++ ){
            count += temperaturas[i];
            if (temperaturas[i] < 0){
                countNegativas++;
            }
        }
        double media = count/numero;
        System.out.println("La media de las "+numero+" temperaturas introducidas es "+media+" y han sido "+countNegativas+" veces negativas" );
        for (int i= 0; i< temperaturas.length;i++){
            System.out.print("Las temperaturas introducidas han sido: "+temperaturas[i]+", ");
        }
        return "";
    }

    /*
    * This method computes a random number (numAzar), and the user has to guess it seven tries (intentos).
    * So while the number hasn't been accepted and we still have tries, the program asks for a number.
    *
    * A hint is also displayed, so once we have introduced a number, the program answers wet
    *
    * */

    public static int adivino(){

        int intentos = 7;
        int numAzar = (int) (Math.random()*100 +1);

        boolean acierto = false;

        while (intentos != 0 || acierto == false){

            System.out.println("Intente adivinar el numero. "+intentos+" intentos");

            Scanner numero = new Scanner(System.in);
            int numeroInt = numero.nextInt();
            if (numeroInt != numAzar){
                intentos--;
                if (numeroInt > numAzar){
                    System.out.println("El numero a adiviniar es menor");
                }else{
                    System.out.println("El numero a adiviniar es mayor");
                }

            }else{
                acierto = true;
                System.out.println("¡ENHORABUENA! ¡HA ACERTADO!");
                break;
            }
            if (intentos < 1){
                System.out.println("ha perdido, el numero a adivinar era "+numAzar);
                break;
            }

        }

        return 1;
    }



    public static void main(String[] args) {

        System.out.println("Introduzca la opción que desea utilizar (1. Calcular consumo de agua 2.Calcular temperatura 3.Adivino)");

        Scanner opcion = new Scanner(System.in);
        int op = opcion.nextInt();

        if (op == 1){ //Checking option one

            System.out.println("Introduzca el numero de m^3 consumidos:"); //ask for the number of consumed water
            Scanner numero_entrada = new Scanner(System.in);
            double numero = numero_entrada.nextDouble(); // Store the numer

            if (numero >0){
                double cuenta = calculoConsumo(numero); //Calling the method that computes it if number is correct
            }else{
                System.out.println("El numero introducido no es correcto"); //error message in case the number introduced isnt correct
            }
        }else if(op == 2){ //Checking option 2
            System.out.println("Introduzca el numero de temperaturas que va introducir");
            Scanner numeroTemp = new Scanner(System.in); //Storing the number of temperatures the user wants to introduce
            int numTemp = numeroTemp.nextInt();
            if (numTemp >0){
                String temperaturaSalida = calculoTemp(numTemp); //If number is correct, calling the method
            }else{
                System.out.println("El numero introducido no es correcto"); //if number incorrect, error message
            }

            System.out.println("");
        }else if (op == 3){ //Checking option 3
            adivino();// Calling the method, we check the introduced values inside this method

        }else{//other option has been chosen, error message
            System.out.println("La opción introducida no se corresponde");
        }
    }
}
