import java.util.Scanner;

public class Coche {

    private double velocidadRecta;
    private double velocidadCurva;

    //Constructors: Without parameters, with only velocidadRecta, with both parameters, with another as parameter

    Coche(){
        velocidadCurva = 0;
        velocidadRecta = 0;
    }
    Coche(double a){
        velocidadRecta = a;
        velocidadCurva = 1;
    }
    Coche(double a, double b){
        velocidadRecta = a;
        velocidadCurva = b;
    }
    Coche(Coche c){
        velocidadCurva = c.getVelocidadCurva();
        velocidadRecta = c.getVelocidadRecta();
    }

//Getters and setters for the parameters

    public double getVelocidadCurva() {
        return velocidadCurva;
    }

    public void setVelocidadCurva(double velocidadCurva) {
        this.velocidadCurva = velocidadCurva;
    }

    public double getVelocidadRecta() {
        return velocidadRecta;
    }

    public void setVelocidadRecta(double velocidadRecta) {
        this.velocidadRecta = velocidadRecta;
    }

    //Methods that control the behaviour of the cars

    public void acelerarRecta(){

        setVelocidadRecta(getVelocidadRecta()+15);
    }
    public void acelerarCurva(){

        setVelocidadCurva(getVelocidadCurva()+5);
    }
    public void frenarRecta(){

        setVelocidadRecta(getVelocidadRecta()-15);
        if(getVelocidadRecta()<= 0){
            setVelocidadRecta(0);
        }
    }
    public void frenarCurva(){

        setVelocidadCurva(getVelocidadCurva()-5);
        if(getVelocidadCurva()<=0){
            setVelocidadCurva(0);
        }
    }
    public void mejorar(){

        setVelocidadRecta(getVelocidadRecta()+15);
        setVelocidadCurva(getVelocidadCurva()+15);
    }
    public double tiempoRecta(double distancia){

        if (getVelocidadRecta() <= 0){
            return -1;

        }else{

            return distancia/getVelocidadRecta();
        }
    }
    public double tiempoCurva(double distancia){
        if (getVelocidadCurva() <= 0 ){
            return -1;
        }else{
            return distancia/getVelocidadCurva();
        }

    }


}

class DemoCoche{

    //printMenu prints the possibilities we have

    public static void printMenu(){
        System.out.println("");
        System.out.println("1. Acelerar coche en recta");
        System.out.println("2. Acelerar coche en curva");
        System.out.println("3. Frenar coche en recta");
        System.out.println("4. Frenar coche en curva");
        System.out.println("5. Mejorar coche");
        System.out.println("6. Calcular tiempo en recta");
        System.out.println("7. Calcular tiempo en curva");
        System.out.println("Seleccione la opción que desee:");

    }

    //Controls the actions of the cars, modifying its speed and computing the time it would take to cover a given distance
    public static Coche acciones(Coche a){
        Scanner reader = new Scanner(System.in);
        int opcion = 0;
        opcion = reader.nextInt();

        switch (opcion){
            case 1:
                a.acelerarRecta();
                System.out.println("Coche acelerado en recta");
                break;
            case 2:
                a.acelerarCurva();
                System.out.println("Coche acelerado en curva");
                break;
            case 3:
                a.frenarRecta();
                System.out.println("Coche frenado en recta");
                break;
            case 4:
                a.frenarCurva();
                System.out.println("Coche frenado en curva");
                break;
            case 5:
                a.mejorar();
                System.out.println("Coche mejorado");
                break;
            case 6:
                System.out.println("Introduzca distancia recta:");
                reader = new Scanner(System.in);
                double distanciaR = reader.nextDouble();
                double tiempoR = a.tiempoRecta(distanciaR);
                System.out.println("Tiempo en recorrer "+tiempoR);
                break;
            case 7:
                System.out.println("Introduzca distancia curva:");
                reader = new Scanner(System.in);
                double distanciaC = reader.nextDouble();
                double tiempoC = a.tiempoCurva(distanciaC);
                System.out.println("Tiempo en recorrer "+tiempoC);
                break;
            case 8:
                double velocidadR, velocidadC;
                velocidadR = a.getVelocidadRecta();
                velocidadC = a.getVelocidadCurva();
                System.out.println("VelocidadRecta "+velocidadR);
                System.out.println("VelocidadCurva "+velocidadC);
                break;

        }
        System.out.println("La velocidad del coche en recta es "+a.getVelocidadRecta()+ " y la velocidad en curva es "+a.getVelocidadCurva());
        return a;
    }

    //Initializes the car according the users options
    public static Coche inicilalizarCoche(){

        System.out.println("Elija opcion de inicializacion: ");
        System.out.println("1. Un argumento (Velocidad recta)");
        System.out.println("2. Dos argumentos (Velocidad recta y Velocidad curva)");
        System.out.println("3. Por defecto");
        System.out.println("0. salir");

        Coche c;

        Scanner reader = new Scanner(System.in);
        double opInicial = 0;
        opInicial = reader.nextDouble();

        if (opInicial == 1){
            System.out.println("Elija la velocidad en recta del coche:");
            reader = new Scanner(System.in);
            double opcion = 0;
            opcion = reader.nextDouble();
            c= new Coche(opcion);
            return c;
        }else if(opInicial == 2){
            System.out.println("Elija la velocidad en recta del coche:");
            reader = new Scanner(System.in);
            double opcion = 0;
            opcion = reader.nextDouble();

            System.out.println("Elija la velocidad en curva del coche:");
            reader = new Scanner(System.in);
            double opcion2 = 0;
            opcion2 = reader.nextDouble();
            c = new Coche(opcion,opcion2);
            return c;
        }else if(opInicial ==3){

            System.out.println("Coche creado, velodicad en recta 0, velocidad en curva 0");
            c = new Coche();
            return c;
        }else if (opInicial== 0) {
            throw new RuntimeException("Program stopped");
        }else{
            throw new RuntimeException("Error en la opcion introducida");
        }

    }

    public static void main(String[] args) {

         System.out.println("Bienvenido");
        while(true){
            Coche c = inicilalizarCoche();
            boolean cont = true;
            while(cont){
                printMenu();
                c = acciones(c);


                System.out.println("Desea continuar: 1 SI,0 Salir");
                Scanner reader = new Scanner(System.in);
                int opcion = 0;
                opcion = reader.nextInt();
                if (opcion != 1) {
                    break;
                }
            }


        }
    }

}